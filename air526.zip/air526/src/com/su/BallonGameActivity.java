package com.su;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tu.Balloon;

public class BallonGameActivity extends Activity {
	private ImageView imgshow;
	private ImageView xunhuan;
	private Button btnRestart;
	private Button btnBack;
	private LinearLayout main;

	private int level = 0, count = 0;
	private int bgn = 0;	

	private int[] yellow = { R.drawable.yellow0, R.drawable.yellow1,
			R.drawable.yellow2, R.drawable.yellow3, R.drawable.yellow4,
			R.drawable.yellow5, R.drawable.yellow6, R.drawable.yellow7,
			R.drawable.yellow8, R.drawable.yellow9, R.drawable.yellow10,
			R.drawable.yellow11, R.drawable.yellow12, R.drawable.yellow13,
			R.drawable.yellow14, R.drawable.yellow15, R.drawable.yellow16,
			R.drawable.yellow17, R.drawable.yellow18, R.drawable.yellow19,
			R.drawable.yellow20, R.drawable.yellow21, R.drawable.yellow22 };

	private int[] bg = { R.drawable.game2_bg, R.drawable.game4_bg,
			R.drawable.game5_bg, R.drawable.game6_bg };

	private sqlEngThread sqlEngine;

	private int recLen = 0;
	private int lesLen = 9;
	private int seLen = 10;
	private int se = 0;

	public int ballsum = 0;

	private String acolor = new String();
	private String amode = new String();

	private TextView txtView;
	private TextView showend;
	private Thread ti;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		imgshow = (ImageView) findViewById(R.id.imgshow);
		xunhuan = (ImageView) findViewById(R.id.xunhuan);
		btnRestart = (Button) findViewById(R.id.btnRestart);
		btnBack = (Button) findViewById(R.id.btnBack);
		txtView = (TextView) findViewById(R.id.show_time);
		showend = (TextView) findViewById(R.id.show_end);
		main = (LinearLayout) findViewById(R.id.Lmain);

		Intent intent = getIntent();
		if (intent.getStringExtra("color") != null) {
			acolor = intent.getStringExtra("color");
		}

		if (intent.getStringExtra("mode") != null) {
			amode = intent.getStringExtra("mode");
		}

		if (amode.equals("正计时")) {

			initGame();
			btnRestart.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					initGame();

				}
			});
		}

		if (amode.equals("倒计时")) {

			initGame1();
			btnRestart.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub

					initGame1();
				}
			});
		}

		btnBack.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				Intent intent = new Intent();
				intent.setClass(BallonGameActivity.this, Balloon.class);
				startActivity(intent);
			}
		});

		xunhuan.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				bgn = (int) (Math.random() * 3);
				main.setBackgroundResource(bg[bgn]);
			}
		});

	}

	private void initGame() {
		// TODO Auto-generated method stub
		level = 0;
		recLen = 0;
		se = 0;

		imgshow.setBackgroundResource(yellow[0]);
		btnRestart.setVisibility(View.INVISIBLE);
		btnBack.setVisibility(View.INVISIBLE);
		showend.setVisibility(View.INVISIBLE);
		txtView.setVisibility(View.VISIBLE);
		

		ti = new Thread(new MyThread());

		sqlEngine = new sqlEngThread(new BallonHandlerYellow());
		sqlEngine.startThead();
		ti.start();
	}

	private void initGame1() {
		// TODO Auto-generated method stub
		level = 0;
		lesLen = 9;
		seLen = 10;

		imgshow.setBackgroundResource(yellow[0]);
		btnRestart.setVisibility(View.INVISIBLE);
		btnBack.setVisibility(View.INVISIBLE);
		showend.setVisibility(View.INVISIBLE);

		ti = new Thread(new MyThread1());

		sqlEngine = new sqlEngThread(new YellowWhileHandler());
		sqlEngine.startThead();
		ti.start();

	}



	class YellowWhileHandler extends Handler {
		@Override
		public void handleMessage(Message msg) {
			if (msg.what == 1) {
				int d = msg.arg1;
				if (d >= 180) {
					count++;
					if (count >= 7) {
						level = level + 1;
						if (level <= 22) {
							imgshow.setBackgroundResource(yellow[level]);
							if (level == 22) {
								ballsum++;
								level = 0;
								imgshow.setBackgroundResource(yellow[level]);

								if (seLen <= 0) {
									
									sqlEngine.stopThead();
									btnRestart.setVisibility(View.VISIBLE);
									btnBack.setVisibility(View.VISIBLE);
									showend.setVisibility(View.VISIBLE);
									txtView.setVisibility(View.INVISIBLE);

									showend.setText("Yes！您吹了 " + ballsum
											+ "个球！");
									imgshow.setBackgroundResource(yellow[level]);
									sqlEngine = null;
									ti = null;
								}
							}
						}
						count = 0;
					}
				}

			}
		}

	}


	class BallonHandlerYellow extends Handler {
		@Override
		public void handleMessage(Message msg) {
			if (msg.what == 1) {
				int d = msg.arg1;
				if (d >= 180) {
					count++;
					if (count >= 5) {
						level++;
						if (level <= 22) {
							imgshow.setBackgroundResource(yellow[level]);
							if (level == 22) {

								sqlEngine.stopThead();
								btnRestart.setVisibility(View.VISIBLE);
								btnBack.setVisibility(View.VISIBLE);
								showend.setVisibility(View.VISIBLE);
								txtView.setVisibility(View.INVISIBLE);

								showend.setText("Wow! 您用了" + se + "." + recLen
										+ "秒！");
								sqlEngine = null;
								ti = null;

							}
						}
						count = 0;
					}
				}
			}
		}
	}

	final Handler handler = new Handler() { // handle
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				recLen++;
				if (recLen == 10) {
					se++;
					recLen = 0;
				}
				txtView.setText(se + ":" + recLen);

			}
			super.handleMessage(msg);
		}
	};

	class MyThread implements Runnable { // thread
		@Override
		public void run() {
			while (level < 22) {
				try {
					Thread.sleep(100);
					Message message = new Message();
					message.what = 1;
					handler.sendMessage(message);
				} catch (Exception e) {
				}
			}
		}
	}

	final Handler handler1 = new Handler() { // handle
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case 1:
				lesLen--;
				if (lesLen == 0) {
					seLen--;
					lesLen = 9;
				}
				txtView.setText(seLen + ":" + lesLen);
			}

		}
	};

	class MyThread1 implements Runnable { // thread
		@Override
		public void run() {

			while (seLen > 0) {
				try {
					Thread.sleep(100); // sleep 1000ms
					Message message = new Message();
					message.what = 1;
					handler1.sendMessage(message);
				} catch (Exception e) {
				}
			}
		}
	}

}
